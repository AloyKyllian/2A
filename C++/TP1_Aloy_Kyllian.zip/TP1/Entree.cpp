#include "Entree.h"

// Définition du constructeur de la classe Entree
Entree::Entree(std::string nom, std::string numero)
    : Nom(nom), NumeroTelephone(numero) {}

// Définition de la méthode d'affichage pour Entree
void Entree::Afficher()
{
    std::cout << "Nom : " << this->Nom << std::endl;
    std::cout << "Numéro de téléphone : " << this->NumeroTelephone << std::endl;
}
