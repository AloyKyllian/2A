#include "Entree.cpp"
#include "Tableau.cpp"
#include "Agenda.cpp"

int main()
{
    // Création de quelques entrées
    Entree entree1("John Doe", "123-456-7890");
    Entree entree2("Jane Smith", "987-654-3210");
    Entree entree3("Bob Johnson", "555-123-4567");

    // Affichage des entrées individuelles
    std::cout << "Entree 1:" << std::endl;
    entree1.Afficher();
    std::cout << "Entree 2:" << std::endl;
    entree2.Afficher();
    std::cout << "Entree 3:" << std::endl;
    entree3.Afficher();

    // Création d'un tableau d'entrees
    Tableau tableau(10);

    // Ajout d'entrees au tableau
    tableau.Ajouter("Alice Johnson", "111-222-3333");
    tableau.Ajouter("Eve Doe", "999-888-7777");

    // Affichage du tableau d'entrees
    std::cout << "\nTableau d'entrees:" << std::endl;
    tableau.Afficher();

    // Suppression d'une entree par nom
    tableau.Supprimer("Eve Doe");

    // Affichage du tableau après suppression
    std::cout << "\nTableau d'entrees après suppression:" << std::endl;
    tableau.Afficher();

    // Création de deux agendas
    Agenda agenda1(10);
    Agenda agenda2(10);

    // Ajout d'entrees aux agendas
    agenda1.Ajouter("Tom Brown", "444-555-6666");
    agenda1.Ajouter("Lucy Smith", "111-222-3333");

    agenda2.Ajouter("Mike Johnson", "777-888-9999");
    agenda2.Ajouter("Alice Johnson", "111-222-3333");

    // Affichage des agendas
    std::cout << "\nAgenda 1:" << std::endl;
    agenda1.Afficher();
    std::cout << "\nAgenda 2:" << std::endl;
    agenda2.Afficher();

    // Concaténation de deux agendas
    agenda1.Concat(agenda2);

    // Affichage de l'agenda après concaténation
    std::cout << "\nAgenda 1 après concaténation:" << std::endl;
    agenda1.Afficher();

    return 0;
}
