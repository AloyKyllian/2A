#include "Tableau.h"

Tableau::Tableau(int taille) : tailleTotale(taille), entrees(new Entree[taille]), nbelem(0)
{
}

Tableau::~Tableau()
{
    delete[] entrees;
}

Tableau::Tableau(const Tableau &autre)
    : tailleTotale(autre.tailleTotale), entrees(new Entree[autre.tailleTotale]), nbelem(autre.nbelem)
{
    for (int i = 0; i < nbelem; i++)
    {
        this->entrees[i] = autre.entrees[i];
    }
}

void Tableau::Afficher()
{
    for (int i = 0; i < nbelem; i++)
    {
        std::cout << "Entrée " << i + 1 << ":" << std::endl;
        this->entrees[i].Afficher();
    }
}

void Tableau::Ajouter(std::string nom, std::string numero)
{
    if (nbelem < tailleTotale)
    {
        this->entrees[nbelem++] = Entree(nom, numero);
    }
    else
    {
        std::cout << "Tableau plein. Impossible d'ajouter une nouvelle entrée." << std::endl;
    }
}

void Tableau::Supprimer(std::string nom, std::string numero)
{
    for (int i = 0; i < this->nbelem; i++)
    {
        if (this->entrees[i].Nom == nom && this->entrees[i].NumeroTelephone == numero)
        {
            for (int j = i; j < this->nbelem - 1; j++)
            {
                this->entrees[j] = this->entrees[j + 1];
            }
            this->nbelem--;
            break;
        }
    }
}

void Tableau::Supprimer(std::string nom)
{
    for (int i = 0; i < this->nbelem; i++)
    {
        if (this->entrees[i].Nom == nom)
        {
            for (int j = i; j < this->nbelem - 1; j++)
            {
                this->entrees[j] = this->entrees[j + 1];
            }
            this->nbelem--;
            i--;
        }
    }
}

int Tableau::GetNbElem()
{
    return this->nbelem;
}

int Tableau::GetTaille()
{
    return this->tailleTotale;
}
