// #include "Agenda.h"
// #include <iostream>

// // Constructeur de la classe Agenda
// Agenda::Agenda(int taille) : tableau(taille) {}

// // Constructeur par copie
// Agenda::Agenda(Agenda &autre) : tableau(autre.tableau) {}

// // Méthode de concaténation d'agendas
// void Agenda::Concat(Agenda &autre)
// {
//     // Obtenez le nombre d'éléments dans l'autre agenda
//     int nbElemAutre = autre.tableau.GetNbElem();

//     // Vérifiez si le tableau actuel a suffisamment d'espace pour contenir les éléments de l'autre agenda
//     if (this->tableau.GetNbElem() + nbElemAutre <= this->tableau.GetTaille())
//     {
//         // Copiez les éléments de l'autre tableau dans celui-ci
//         for (int i = 0; i < nbElemAutre; i++)
//         {
//             Ajouter(autre.tableau.entrees[i].Nom, autre.tableau.entrees[i].NumeroTelephone);
//         }
//     }
//     else
//     {
//         // Gérer l'erreur de capacité insuffisante
//         std::cout << "Erreur : Capacité maximale atteinte lors de la concaténation." << std::endl;
//     }
// }

// // Ajouter une entrée à l'agenda
// void Agenda::Ajouter(std::string nom, std::string numero)
// {
//     tableau.Ajouter(nom, numero);
// }

// // Supprimer une entrée par nom et numéro
// void Agenda::Supprimer(std::string nom, std::string numero)
// {
//     tableau.Supprimer(nom, numero);
// }

// // Supprimer une entrée par nom
// void Agenda::Supprimer(std::string nom)
// {
//     tableau.Supprimer(nom);
// }

// // Méthode d'affichage de l'agenda
// void Agenda::Afficher()
// {
//     std::cout << "Agenda : " << std::endl;
//     this->tableau.Afficher();
// }

#include "Agenda.h"

// Constructeur
Agenda::Agenda(int taille)
{
    tableau = new Tableau(taille);
}

// Constructeur par copie
Agenda::Agenda(Agenda &autre)
{
    tableau = new Tableau(*(autre.tableau));
}

// Destructeur
Agenda::~Agenda()
{
    delete tableau;
}

// Méthode de concaténation d'agendas
void Agenda::Concat(Agenda &autre)
{
    int nbElemAutre = autre.tableau->GetNbElem();
    int tailleTotaleActuelle = tableau->GetTaille();

    if (tableau->GetNbElem() + nbElemAutre <= tailleTotaleActuelle)
    {
        for (int i = 0; i < nbElemAutre; i++)
        {
            const Entree &entreeAutre = autre.tableau->entrees[i];
            tableau->Ajouter(entreeAutre.Nom, entreeAutre.NumeroTelephone);
        }
    }
    else
    {
        std::cout << "Erreur : Capacité maximale atteinte lors de la concaténation." << std::endl;
    }
}

// Ajouter une entrée à l'agenda
void Agenda::Ajouter(std::string nom, std::string numero)
{
    tableau->Ajouter(nom, numero);
}

// Supprimer une entrée par nom et numéro
void Agenda::Supprimer(std::string nom, std::string numero)
{
    tableau->Supprimer(nom, numero);
}

// Supprimer une entrée par nom
void Agenda::Supprimer(std::string nom)
{
    tableau->Supprimer(nom);
}

// Méthode d'affichage de l'agenda
void Agenda::Afficher()
{
    tableau->Afficher();
}