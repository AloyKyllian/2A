#include "Document.h"

// Constructeur par défaut
Document::Document() : titre(""), resume(nullptr), auteur("") {}

// Constructeur avec paramètres
Document::Document(std::string titre, std::string resume, std::string auteur)
    : titre(titre), resume(new std::string(resume)), auteur(auteur) {}

// Constructeur de copie
Document::Document(const Document &other)
    : titre(other.titre), resume(new std::string(*(other.resume))), auteur(other.auteur) {}

// Destructeur
Document::~Document()
{
    delete resume;
}

// Méthode pour afficher le document
void Document::afficher() const
{
    std::cout << "Titre: " << titre << "\nRésumé: " << *resume << "\nAuteur: " << auteur << std::endl;
}

// Méthode pour cloner le document
Document Document::clone() const
{
    return Document(*this);
}

Document &Document::operator=(const Document &other)
{
    if (this != &other)
    {
        titre = other.titre;
        delete resume;
        resume = new std::string(*(other.resume));
        auteur = other.auteur;
    }
    return *this;
}