"""
package etape2

Rassemble les modules et classes pour la réalisation de l'etape 2 du TP IA des SRI2A
"""
