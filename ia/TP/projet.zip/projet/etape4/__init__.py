"""
package etape4

Rassemble les modules et classes pour la réalisation de l'etape 4 du TP IA des SRI2A
"""
