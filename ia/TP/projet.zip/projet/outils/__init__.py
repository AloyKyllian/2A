"""
package outils

Rassemble les modules et classes outils pour la réalisation du TP IA des SRI2A
"""
