"""
package etape3

Rassemble les modules et classes pour la réalisation de l'etape 3 du TP IA des SRI2A
"""
